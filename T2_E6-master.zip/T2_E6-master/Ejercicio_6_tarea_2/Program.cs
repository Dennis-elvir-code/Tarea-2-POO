﻿using System;

public class Program
{
    // Método que calcula el promedio de una lista variable de números
    public static double promedio(params double[] numeros)
    {
        // Verificar si se proporcionó al menos un número
        if (numeros.Length == 0)
        {
            throw new ArgumentException("Se requiere al menos un número para calcular el promedio.");
        }

        double suma = 0;

        // Iterar sobre cada número y sumarlos
        foreach (double numero in numeros)
        {
            suma += numero;
        }

        // Calcular el promedio dividiendo la suma total entre la cantidad de números
        double promedio = suma / numeros.Length;

        // Retornar el promedio calculado
        return promedio;
    }

    public static void Main(string[] args)
    {
        // Ejemplo de uso del método promedio

        // Calcular el promedio de 2.5, 3.8 y 4.2
        double resultado1 = promedio(2.5, 3.8, 4.2);
        Console.WriteLine("El promedio es: " + resultado1);

        // Calcular el promedio de 10, 20, 30, 40 y 50
        double resultado2 = promedio(10, 20, 30, 40, 50);
        Console.WriteLine("El promedio es: " + resultado2);
    }
}
